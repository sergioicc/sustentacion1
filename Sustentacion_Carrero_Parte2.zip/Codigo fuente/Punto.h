#ifndef UNTITLED_PUNTO_H
#define UNTITLED_PUNTO_H
class Punto {
public:
    float x, y, z;

    Punto(float xVal, float yVal, float zVal) : x(xVal), y(yVal), z(zVal) {}
    Punto ()=default;
    Punto operator-(const Punto& other) const {
        return Punto(x - other.x, y - other.y, z - other.z);
    }

    Punto operator+(const Punto& other) const {
        return Punto(x + other.x, y + other.y, z + other.z);
    }
};
#endif //UNTITLED_PUNTO_H//